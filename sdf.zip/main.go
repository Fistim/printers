package main
// Golang - Сила!
import(
	"bufio"
	"fmt"
	"os"
	"github.com/boombuler/barcode"
	"github.com/boombuler/barcode/qr"
	"image"
	"image/png"
	"log"
	"net/http"
	"strings"
	"gorm.io/gorm"
  	"gorm.io/driver/sqlite"
  	"html/template"
)
/*

type Product struct {
  gorm.Model
  Code  string
  Price uint
}
*/

type ViewData struct{
	Title string
	PrinterNames []string
}

type Printers struct{
	gorm.Model
	ID uint
	Name string `gorm:"type:text"`
}

type Cartridge struct{
	gorm.Model
	ID uint
	Name string `gorm:"type:text"`
}

type CartridgeOfPrinter struct{
	gorm.Model
	CartridgeID uint
	PrinterID uint
}

func main(){
	http.HandleFunc("/", PrinterList)

	http.ListenAndServe(":8888", nil)
}

func PrinterList(w http.ResponseWriter, r *http.Request){
	db, _ := gorm.Open(sqlite.Open("printer.db"), &gorm.Config{})

	var PrinterList []string
	db.Select("Name").Find(&PrinterList)

	data := ViewData{
		Title: "Generate QR",
		PrinterNames: PrinterList 
	}

	
	fmt.Println(PrinterList)
	tmpl, _ := template.ParseFiles("generate.html")
    tmpl.Execute(w, PrinterList)
}

func generateFromText(){
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Enter printer name: ")
	text, err := reader.ReadString('\n')
	if err != nil{
		fmt.Println("Something went wrong...")
	}
	text = strings.Replace(text, "\n", "", -1)
	code, err := qr.Encode(text, qr.L, qr.Unicode)
	if err != nil {
		fmt.Println("Something went wrong...")
	}
	if text != code.Content() {
		log.Fatal("data differs")
	}
	code, err = barcode.Scale(code, 300, 300)
	if err != nil {
		log.Fatal(err)
	}

	writePng("test.png", code)
}

func writePng(filename string, img image.Image) {
	file, err := os.Create(filename)
	if err != nil {
		log.Fatal(err)
	}
	err = png.Encode(file, img)
	if err != nil {
		log.Fatal(err)
	}
	file.Close()
}