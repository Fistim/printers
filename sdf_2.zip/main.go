package main
// Golang - Сила!
import(
	"fmt"
	"os"
	"github.com/boombuler/barcode"
	"github.com/boombuler/barcode/qr"
	"image"
	"image/png"
	"log"
	"net/http"
	"strings"
	"gorm.io/gorm"
  	"gorm.io/driver/sqlite"
  	"html/template"
)

type ViewData struct{
	Title string
	PrinterNames []string
	CartridgeNames []string
}

type Printers struct{
	ID uint `gorm:"type:integer"`
	Name string `gorm:"type:text"`
}

type Cartridges struct{
	ID uint `gorm:"type:integer"`
	Name string `gorm:"type:text"`
}

type CartridgeOfPrinter struct{
	CartridgeID uint `gorm:"type:integer"`
	PrinterID uint `gorm:"type:integer"`
}

func main(){
	http.HandleFunc("/", PrinterList)
	http.HandleFunc("/generate", GenerateQR)
	http.HandleFunc("/addprinter", AddPrinter)
	http.HandleFunc("/addcartridge", AddCartridge)
	http.HandleFunc("/cartridgeOfPrinter", AddCartridgeOfPrinter)
	fmt.Println("Server is listening...")
	http.ListenAndServe(":8888", nil)
}

func AddCartridgeOfPrinter(w http.ResponseWriter, r *http.Request){
	db, _ := gorm.Open(sqlite.Open("printer.db"), &gorm.Config{})
	r.ParseForm()
	cartridgeName := strings.Join(r.Form["cartridges"], "")
	// printerName := strings.Join(r.Form["printers"], "")
	var cartridgeID uint
	db.Where("Name = ?", cartridgeName).Select("ID").First(&cartridgeID)
	fmt.Println(string(cartridgeID))
	fmt.Println("asdasd")
}

func AddCartridge(w http.ResponseWriter, r *http.Request){
	db, _ := gorm.Open(sqlite.Open("printer.db"), &gorm.Config{})
	r.ParseForm()
	text := strings.Join(r.Form["cartridgeName"], "")
	var newCartridge Cartridges
	newCartridge.Name = text
	db.Create(&newCartridge)
	http.Redirect(w, r, "/", 302)
}

func AddPrinter(w http.ResponseWriter, r *http.Request){
	db, _ := gorm.Open(sqlite.Open("printer.db"), &gorm.Config{})
	r.ParseForm()
	text := strings.Join(r.Form["printerName"], "")
	var newPrinter Printers
	newPrinter.Name = text
	db.Create(&newPrinter)
	http.Redirect(w, r, "/", 302)
}

func GenerateQR(w http.ResponseWriter, r *http.Request){
	r.ParseForm()
	text := strings.Join(r.Form["printer"], "")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", text + ".png"))
	generateFromText(text)
	http.ServeFile(w, r, text)
}

func PrinterList(w http.ResponseWriter, r *http.Request){
	db, _ := gorm.Open(sqlite.Open("printer.db"), &gorm.Config{})

	var PrinterList []Printers
	db.Find(&PrinterList)
	var PrinterName []string
	for _, pr := range PrinterList{
		PrinterName = append(PrinterName, pr.Name)
	}

	var CartridgeList []Cartridges
	db.Find(&CartridgeList)
	var CartridgeName []string
	for _, ca := range CartridgeList{
		CartridgeName = append(CartridgeName, ca.Name)
	}


	data := ViewData{
		Title: "Generate QR",
		PrinterNames: PrinterName,
		CartridgeNames: CartridgeName,
	}

	
	// fmt.Println(PrinterList)
	tmpl, _ := template.ParseFiles("generate.html")
    tmpl.Execute(w, data)
}

func generateFromText(text string){
	text = strings.Replace(text, "\n", "", -1)
	code, err := qr.Encode(text, qr.L, qr.Unicode)
	if err != nil {
		fmt.Println("Something went wrong...")
	}
	if text != code.Content() {
		log.Fatal("data differs")
	}
	code, err = barcode.Scale(code, 300, 300)
	if err != nil {
		log.Fatal(err)
	}

	writePng(text, code)
}

func writePng(filename string, img image.Image) {
	file, err := os.Create(filename)
	if err != nil {
		log.Fatal(err)
	}
	err = png.Encode(file, img)
	if err != nil {
		log.Fatal(err)
	}
	file.Close()
}